package pk.cuiatd.calc;

public class Test {

	public static void main(String[] args) {
		Calculator calc = new Calculator();
		System.out.println(calc.sum(2, 3));

	}

}
